using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX ScreenCapture")]
[assembly: Guid("9a892054-a73a-4fc1-9166-e97b425b874a")]