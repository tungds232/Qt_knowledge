using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX ImageEffectsLib")]
[assembly: Guid("084988ba-cc50-4f60-90f7-3a98c4073087")]