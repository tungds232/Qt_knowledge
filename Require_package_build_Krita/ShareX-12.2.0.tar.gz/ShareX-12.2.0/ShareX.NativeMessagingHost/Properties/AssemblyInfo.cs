﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX NativeMessagingHost")]
[assembly: Guid("254e398d-f7f5-4b2a-9024-5c121ea6c564")]