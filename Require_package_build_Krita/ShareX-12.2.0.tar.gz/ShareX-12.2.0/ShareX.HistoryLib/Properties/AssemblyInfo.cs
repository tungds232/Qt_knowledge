using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX HistoryLib")]
[assembly: Guid("158992c9-b38c-4d85-b95b-1b46e7f75940")]