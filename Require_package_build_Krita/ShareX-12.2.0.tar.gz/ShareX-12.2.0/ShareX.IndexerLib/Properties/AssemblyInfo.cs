﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX IndexersLib")]
[assembly: Guid("90cfdab0-aabc-4c96-81ea-f50f08283489")]