using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX HelpersLib")]
[assembly: Guid("0836c289-a8c6-4b3c-ac1e-2a2957480f6a")]