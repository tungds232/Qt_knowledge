﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX DesktopBridgeHelper")]
[assembly: Guid("2bf9aebb-b104-4b72-8298-04ca6d23b0e0")]