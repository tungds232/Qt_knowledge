﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX Launcher")]
[assembly: Guid("7f6adfc5-2563-4a5f-b202-93b553578719")]