﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX Setup")]
[assembly: Guid("e16c72bd-71a1-4663-a92d-31e0d58df3b9")]