﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ShareX MediaLib")]
[assembly: Guid("1a190e53-1419-4cc2-b0e5-3bc7ea861c8b")]